<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Create new service page callback
function homelab_create_service_page() {
    ob_start();
    // Handle form submission
    if (isset($_POST['submit'])) {
        homelab_save_service();
        wp_redirect(admin_url('admin.php?page=homelab-list-services'));
        exit;
    }

    // Render the create service form
    ?>
    <div class="wrap">
        <h1>Create New Service</h1>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th><label for="name">Name</label></th>
                    <td><input type="text" name="name" id="name" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="description">Description</label></th>
                    <td><textarea name="description" id="description" rows="4" cols="50"></textarea></td>
                </tr>
                <tr>
                    <th><label for="icon">Icon</label></th>
                    <td>
                        <select name="icon" id="icon">
                            <option value="">Select an icon</option>
                            <!-- Add Font Awesome icon options here -->
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="image">Service Image</label></th>
                    <td>
                        <select name="image" id="image">
                            <option value="">Select an image</option>
                            <?php
                            global $wpdb;
                            $table_name_images = $wpdb->prefix . 'homelab_service_images';
                            $images = $wpdb->get_results("SELECT * FROM $table_name_images");
                            foreach ($images as $image) {
                                echo '<option value="' . $image->id . '">' . $image->name . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="tags">Tags</label></th>
                    <td><input type="text" name="tags" id="tags" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="category">Category</label></th>
                    <td>
                        <?php
                        wp_dropdown_categories(array(
                            'name' => 'category',
                            'id' => 'category',
                            'taxonomy' => 'category',
                            'hide_empty' => 0,
                            'show_option_none' => 'Select a category',
                        ));
                        ?>
                    </td>
                </tr>
                <tr>
                    <th><label for="color">Color</label></th>
                    <td><input type="color" name="color" id="color"></td>
                </tr>
                <tr>
                    <th><label for="parent">Parent</label></th>
                    <td>
                        <select name="parent" id="parent">
                            <option value="">Select a parent service</option>
                            <?php
                            global $wpdb;
                            $table_name_services = $wpdb->prefix . 'homelab_services';
                            $services = $wpdb->get_results("SELECT * FROM $table_name_services");
                            foreach ($services as $service) {
                                echo '<option value="' . $service->id . '">' . $service->name . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="service_url">Service URL</label></th>
                    <td><input type="text" name="service_url" id="service_url" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="alt_page_url">Alternative Page URL</label></th>
                    <td><input type="text" name="alt_page_url" id="alt_page_url" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="status_check">Status Check</label></th>
                    <td><input type="checkbox" name="status_check" id="status_check" value="1"></td>
                </tr>
                <tr class="status-check-fields" style="display: none;">
                    <th><label for="status_check_url">Status Check URL</label></th>
                    <td><input type="text" name="status_check_url" id="status_check_url" class="regular-text"></td>
                </tr>
                <tr class="status-check-fields" style="display: none;">
                    <th><label for="disable_ssl">Disable SSL</label></th>
                    <td><input type="checkbox" name="disable_ssl" id="disable_ssl" value="1"></td>
                </tr>
                <tr class="status-check-fields" style="display: none;">
                    <th><label for="accepted_response">Accepted HTTP Response</label></th>
                    <td><input type="text" name="accepted_response" id="accepted_response" class="regular-text"></td>
                </tr>
                <tr class="status-check-fields" style="display: none;">
                    <th><label for="polling_interval">Polling Interval (seconds)</label></th>
                    <td><input type="number" name="polling_interval" id="polling_interval" class="regular-text" min="5"></td>
                </tr>
                <tr class="status-check-fields" style="display: none;">
                    <th><label for="notify_email">Notify Email</label></th>
                    <td><input type="email" name="notify_email" id="notify_email" class="regular-text"></td>
                </tr>
            </table>
            <?php submit_button('Create Service'); ?>
        </form>
    </div>
    <script>
    jQuery(document).ready(function($) {
        $('#status_check').change(function() {
            $('.status-check-fields').toggle(this.checked);
        });
    });
    </script>
    <?php
    ob_end_flush();
}

// Save service details
function homelab_save_service() {
    ob_start();
    global $wpdb;

    $table_name_services = $wpdb->prefix . 'homelab_services';

    $name = sanitize_text_field($_POST['name']);
    $description = sanitize_textarea_field($_POST['description']);
    $icon = sanitize_text_field($_POST['icon']);
    $image_id = intval($_POST['image']);
    $tags = sanitize_text_field($_POST['tags']);
    $category_id = intval($_POST['category']);
    $color = sanitize_hex_color($_POST['color']);
    $parent_id = intval($_POST['parent']);
    $service_url = sanitize_text_field($_POST['service_url']);
    $alt_page_url = sanitize_text_field($_POST['alt_page_url']);
    $status_check = isset($_POST['status_check']) ? 1 : 0;
    $status_check_url = sanitize_text_field($_POST['status_check_url']);
    $disable_ssl = isset($_POST['disable_ssl']) ? 1 : 0;
    $accepted_response = sanitize_text_field($_POST['accepted_response']);
    $polling_interval = intval($_POST['polling_interval']);
    $notify_email = sanitize_email($_POST['notify_email']);

    $wpdb->insert(
        $table_name_services,
        array(
            'name' => $name,
            'description' => $description,
            'icon' => $icon,
            'image_id' => $image_id,
            'tags' => $tags,
            'category_id' => $category_id,
            'color' => $color,
            'parent_id' => $parent_id,
            'service_url' => $service_url,
            'alt_page_url' => $alt_page_url,
            'status_check' => $status_check,
            'status_check_url' => $status_check_url,
            'disable_ssl' => $disable_ssl,
            'accepted_response' => $accepted_response,
            'polling_interval' => $polling_interval,
            'notify_email' => $notify_email,
        )
    );

    $service_id = $wpdb->insert_id;

    if ($status_check) {
        homelab_add_service_check_schedule($service_id, $polling_interval);
    }

    // Redirect to the list services page after saving
    //wp_redirect(admin_url('admin.php?page=homelab-list-services'));
    //ob_end_flush(); // Send output buffer and turn off buffering
    //exit;
}