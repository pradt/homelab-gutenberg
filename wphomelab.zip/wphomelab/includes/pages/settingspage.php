<?php
/****
 * 1. Setting to enable encryption
 *
 * 2. Enable/Deactivate API
 * 3. Enable Debug Pages
 * 4. Constrain Service Data table (sechedule jobs daily to limit it to x days)
 * 5. Stop all fetchs (pause)
 * 6. Start all fetchs (schedule )
 */